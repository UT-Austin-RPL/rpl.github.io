Dataset
-------
1. To download images, you need to create an ImageNet account. 
   See detailed instructions [here](http://image-net.org/download-images).
2. The affordance dataset can be downloaded using the Matlab script (fetchDataset.m).
   Update the user name and access key with your account information obtained from ImageNet website.
3. The image ids of the training and test sets are in training\_samples.txt and test\_samples.txt. 
4. The affordance annotations can be found in affordance\_annotations.txt.

Knowledge Base
--------------
A subset of weighted general rules in our knowledge base (in Markov Logic) can be found in relation\_mln.txt.

Resources
---------
[ImageNet](http://image-net.org)
[Stanford 40 Actions](http://vision.stanford.edu/Datasets/40actions.html)
[Alchemy (Markov Logic)](http://alchemy.cs.washington.edu/)
[Human Pose Annotation Tools](http://www.eecs.berkeley.edu/Research/Projects/CS/vision/shape/poselets/)
