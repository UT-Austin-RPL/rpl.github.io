synsets = importdata('synsets/ImageNetSynsets.txt');

for i = 1 : length(synsets)

    fprintf('Downloading synset %s...\n', synsets{i});
    
    sid = textscan(synsets{i}, '%s', 'delimiter', ' ');
    sid = sid{1};
    
    nid = sid{2};
    sid = sid{1};
    
    if exist(sprintf('%s.tar', nid))
        continue;
    end
    
    api = 'http://www.image-net.org/download/synset?wnid=%s&username={{YourID}}&accesskey={{YourAccessKey}}&release=latest';
    url = sprintf(api, nid);
    
    urlwrite(url, sprintf('%s.tar', nid));
end
